package in.ineuron.bean;

import java.util.Date;

//Traget Class
public class WishMessageGenerator {
	
	//Dependent class
	private Date date;
	
	
	

}
